
<html>
<head>
    <title>Added-New users</title>
    
</head>
<body style="background-color: gray; padding: 0;">
     <?php

        include("config.php"); ?>
       
        <script type='text/javascript'>alert('User added');window.location.href='adduser.php'</script>";
        }
    
    ?>

</body>
</html>
-->